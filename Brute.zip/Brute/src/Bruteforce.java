/******************************************************************************
 *  Compilation:  javac Bruteforce.java
 *  Execution:    java Bruteforce   (must answer all questions asked in command prompt)
 *  Dependencies: none (Required Files: AllWord.txt)
 *
 *  Reads in Columnar Cipher plaintext and/or cyphertext.
 *
 ******************************************************************************/
import java.io.*;
import java.util.*;

//brute forces the double transposition columnar cipher
public class Bruteforce{
    public static List <String> lstPerm = new ArrayList <String> (); //global variable //holds the current permutations

    public static Set <String> v_dict = new HashSet <String> (); // global variable //hashset is a set that makes storing values easier

    public static void main (String [] args)
    throws IOException
    { //read this to understand how PrintStream works- https://docs.oracle.com/javase/7/docs/api/java/io/PrintStream.html
    PrintStream o = new PrintStream(new File("ColumCipherOutput.txt"));
        PrintStream console = System.out;
        // Use stored value for output stream
        System.setOut(console);      
       
        //decrypt("TINESAXEOAHTFXHTLTHEYMAIIAIXTAPNGDLOSTNHMX", "532164");
       
        //encrypt("TOMATIOSINTHNEIGHTSAHDEFAMLIYHEALHTYVEGEATBLEFRIUTYOUAERHACKENRIGHTIDSARKDAIYSBRIGTH","7532164");
        //decrypt("THSMLERAEIAGATTAAGFUKTDIMNHFEEEOCHKRINALHAIENDITOIGEHVLYAGRBOEHITTURRSYHTSIDYYBTHIAS","7532164");
       
        //decrypt(text2,perm2);
       
        // reads output stream to ask and answer questions 
        Scanner v_in = new Scanner(System.in);
        System.out.print("Do you optionally want to encrypt the text first? Please enter you choice (Y/N) : ");
        String v_Opt = v_in.nextLine().toUpperCase();
        System.out.println("You entered:" + v_Opt + ":");
        if (! (v_Opt.equals("Y") || v_Opt.equals("N") ))
        {    
        System.out.println("!!Please Enter your choice either 'Y' or 'N'");
            System.out.println("!!!!!!CLOSING THE PROGRAM!!!!!!");
            v_in.close();
            return;
        }
        // simple syntax to read stream and encrypt plaintext
        if (v_Opt.equals("Y"))
        {
            System.out.print("Please enter the Text to Encrypt(Max Length is 100. Ex: THETOMATOISAPLANTOFTHENIGHTSHADEFAMILY) : ");
            String v_Text = v_in.nextLine();
            int v_TextLen = v_Text.length();
            if (v_TextLen > 100) {
                System.out.println("!!The Max Encrypt Text size is 100. To to avoid long running program, please enter Encrypt Text <= 100.");
                System.out.println("!!!!!!CLOSING THE PROGRAM!!!!!!");
                v_in.close();
                return;
            }
            System.out.print("Please enter Encrypt Key seperated by space(Max Length is 7. Ex: 532164) : ");
            String key = v_in.nextLine();
            if (key.length() > 7) {
                System.out.println("!!To to avoid long running program, please enter Encrypt Key of length <= 7, as with 7 it generates Factorial(7)=5040 permutations.");
                System.out.println("!!!!!!CLOSING THE PROGRAM!!!!!!");
                v_in.close();
                return;
            }
           
            String [][] arr1 = encrypt(v_Text, key);
        }
       
        //String [][] arr1 = encrypt("THETOMATOISAPLANTOFTHENIGHTSHADEFAMILY", "532164");
       
        System.out.println("------------------------------------------------------------");
        System.out.println("****************** DECRYPTING THE TEXT ******************");
        System.out.println("------------------------------------------------------------");
       
        //syntax to decrypt text using given key_length
        System.out.println();
        System.out.print("Please enter the Text to Decrypt (Max Length is 100. TINESAXEOAHTFXHTLTHEYMAIIAIXTAPNGDLOSTNHMX): ");
        String v_DecText = v_in.nextLine();
        if (v_DecText.length() > 100) {
            System.out.println("!!The Max Decrypt Text size is 100. To to avoid long running program, please enter Decrypt Text <= 100.");
            System.out.println("!!!!!!CLOSING THE PROGRAM!!!!!!");
            v_in.close();
            return;
        }
        System.out.print("Please guess a lengh between 1 and 7 (Ex:6)  : ");
        String DecKeyLen = v_in.nextLine();
        int dKeyLen = Integer.parseInt(DecKeyLen);

        if (dKeyLen > 7) {
            System.out.println("!!To to avoid long running program, please enter Decrypt Key <= 7, as with 7 it generates Factorial(7)=5040 permutations.");
            System.out.println("!!!!!!CLOSING THE PROGRAM!!!!!!");
            v_in.close();
            return;
        }
        System.out.println();
       // reads the dictionary All.words.txt and stores all words in a HashSet (because it makes storing elements easier)
        Scanner f_scan = new Scanner(new File("AllWords.txt"));

        while (f_scan.hasNext()) {
            v_dict.add(f_scan.nextLine().toUpperCase());
        }
        f_scan.close();  
       
        System.out.println();
        System.out.println("***********************************************************************************");
        System.out.println("The program is still running, please Check 'ColumCipherOutput.txt' file to see the result");
        System.out.println("************************************************************************************");
        System.out.println();
        System.out.println();
        System.setOut(o);
       
        String v_str = "";
        for (int i = 1; i <= dKeyLen; i++) {
            v_str = v_str + i;
        }
        System.out.println("Starting Permute****");
        List <String> perm = new ArrayList <String> ();
        perm = Find_Permutation("", v_str);
        System.out.println("------------------- START: PERMUTING DECRYPT KEYS ---------------------");
        System.out.println("DIFFRENT PERMUTAION DECRYPT KEYS ARE:");
        for (String v_Int: perm) {
            System.out.print("xxxxxxxx ");
            System.out.print(v_Int);
            System.out.println(" xxxxxxxxx");
        }
       
        for (String v_Int: perm) {
            System.out.println("");
            System.out.println("");
            System.out.println("##################################################################################################################");
            System.out.print("TRYING WITH DECRYPTION KEY:" + v_Int);

            decrypt(v_DecText, v_Int);
           
            System.out.println("");
            System.out.println("-----------------------------------------------------------------------------------------------------------------");
        }
       
        System.out.println();
        System.out.println();
        System.out.println("*********************************************************************************");
        System.out.println("The program has ended.");
        System.out.println("*********************************************************************************");
       
        System.setOut(console);
        System.out.println("*********************************************************************************");
        System.out.println("The program has ended. Please Check 'ColumCipherOutput.txt' file to see the result");
        System.out.println("*********************************************************************************");        
        v_in.close();
       
        //decrypt(v_DecText, "532164");
        //decrypt("TINESAXEOAHTFXHTLTHEYMAIIAIXTAPNGDLOSTNHMX", "532164");
    }
   
     //to read encrypted text
     public static String printEncrypted (String [][] arr){
        String cyphertext = "";
        for (int j=0; j < arr[0].length; j++){
            for (int i = 0; i < arr.length; i++){
                cyphertext = cyphertext + arr[i][j]; //concatenates string (concat function did not work??)
            }
        }
        System.out.println ("Cyphertext: " + cyphertext);
        return cyphertext;
    }
     
     //to read decrypted text
     public static String printDecrypted (String [][] arr){
         String plaintext = "";
         for (int i=0; i < arr.length; i++){
             for (int j = 0; j < arr[0].length; j++){
                 plaintext = plaintext + arr[i][j]; //concatenates string (concat function did not work??)
             }
         }
         System.out.println ("Plaintext: " + plaintext);
         
         List < List <String>> v_Result = new ArrayList < > ();
         Stack <String> v_word = new Stack <String> ();
         System.out.println("***Start Word Search for:*** " + plaintext);
         Find_In_Dict(plaintext, v_word, v_dict, v_Result);  
         for (List <String> v_out: v_Result) {
             System.out.println("=============================================================POSSIBLE MATCH FOUND==========================================================================");
             for (String word: v_out) {
                 System.out.print(word + " ");
             }
             System.out.println("(Matching " + v_out.size() + " words)");
         }
         System.out.println("***Ended Word Search for:*** " + plaintext);
         
         return plaintext;
     }

     
     //Encrypts plaintext
     // creates a new array with same columns and rows, but columns are rearranged according to permutated key;
     //Here are some examples of how encrypt works:
     //String [][] arr1 = encrypt("THETOMATOISAPLANTOFTHENIGHTSHADEFAMILY", "532164");
     public static String [] [] encrypt(String text, String perm){
         if (text == null) throw new IllegalArgumentException("Please enter a plain text");
         //determines array cols (horizontal, counted vertically) and array rows (vertical, counted horizontally)
         int cols = perm.length();
         int text_len = text.length();
         int rows = text_len / cols;
         if (text_len % cols > 0) rows++;
         // initilaizes array
         System.out.println ("cols: " + cols + " " + "rows " + rows );
         String [][] arr1 = new String [rows][cols];
         // writes plain text into array (write by rows)
         int index = 0;
         String value = null;
         for (int i = 0; i<rows; i++) {
             for (int j=0; j <cols; j++){
                 if (index < text_len) value = Character.toString(text.charAt(index));
                 else value = "X";
                 arr1[i][j] = value;
                 index++;
             }
         }
         String [] [] arr2 = new String [rows][cols];
         for (int j=0; j<cols; j++){
             int n = Integer.parseInt (Character.toString(perm.charAt(j))) - 1;
             for (int i=0; i<rows; i++){
                 arr2[i][n] = arr1[i][j];
             }
         }
         printEncrypted (arr2);
         return arr2;
     }

     //Decrypts cyphertext
    //Here are some examples of how decrypt works:
    //String arr [][] = decrypt("TINESAXEOAHTFXHTLTHEYMAIIAIXTAPNGDLOSTNHMX", "532164"); // (5,3,2,1,6,4) => Tomato // THE TOMATO IS A PLANT OF THE NIGHTSHADE FAMILY
    //String arr [][] = decrypt ("MERHMHSAASALYIEUNSYK", "14532"); // (1,4,5,3,2) => Apple // MY NAME IS SHREYA SHUKLA
    public static String [] [] decrypt(String text, String perm){
        if (text == null) throw new IllegalArgumentException("Please enter a cipher text");
        //determines array cols (horizontal, counted vertically) and array rows (vertical, counted horizontally)
        int cols = perm.length();
        int text_len = text.length();
        int rows = text_len / cols;
        if (text_len % cols > 0) rows++;
        // initilaizes array
        //System.out.println ("cols: " + cols + " " + "rows " + rows );
        String [] [] arr1 = new String [rows][cols];
        // writes cypher text into array (write by columns)
        int index = 0;
        String value = null;
        for (int j=0; j <cols; j++) {
            for (int i = 0; i<rows; i++){
                if (index < text_len) value = Character.toString(text.charAt(index));
                else value = "X";
                arr1[i][j] = value;
                index++;
            }
        }
        // creates a new array with same columns and rows, but columns are rearranged according to permutated key;
        String [] [] arr2 = new String [rows][cols];
        for (int j=0; j<cols; j++){
            int n = Integer.parseInt (Character.toString(perm.charAt(j))) -1;
            for (int i=0; i<rows; i++){
                arr2[i][j] = arr1[i][n];
            }
        }
        printDecrypted (arr2);
        return arr2;
    }
    // finds words in a dictionary
    // recursive function
    // takes v_inputStr (the plaintext)
    // reads v_dict (the dictionary) and pops words that are found in the input string to the Stack v_wrd
    // when all this is over it stores its output to v_Results, a array list of array lists, which stores all the wordlists
    public static void Find_In_Dict(String v_inputStr,
            Stack <String> v_wrd, Set <String> v_dict, List < List <String>> v_Result) {
            int i = 0;
            while (i < v_inputStr.length()) {
                String v_substr = v_inputStr.substring(0, i + 1);
                if (v_dict.contains(v_substr)) {
                    v_wrd.push(v_substr);
                    if (i == v_inputStr.length() - 1) {
                        v_Result.add(new ArrayList <String> (v_wrd));
                    } else {
                        Find_In_Dict(v_inputStr.substring(i + 1), v_wrd, v_dict, v_Result);
                    }
                    v_wrd.pop();
                }
                i++;
            }
        }        
    // finds all permutations of a given string
    // Recursive function
    // takes in 2 arguments and returns a list of all the permutations of a number, str.length()
    private static List <String> Find_Permutation(String leftStr, String str) {
        int n = str.length();
        if (n == 0) {
            lstPerm.add(leftStr.trim()); //.trim() removes whitespace from both ends of a string
        } else {
            for (int i = 0; i < n; i++) {
                Find_Permutation(leftStr + "" + str.charAt(i), str.substring(0, i) + str.substring(i + 1, n)); //recursion
            }
        }
        return lstPerm;
    }

}